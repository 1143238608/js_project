function test1(){
	var a = 1000;
	var b = a + 2000;
	var c = b + 3000;
	var d = c + 4000;
	var e = d + 5000;
	var f = e + 6000;
	return f;
}
console.log( test1() );
//输出 21000