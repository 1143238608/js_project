function People(name) {
    this.name = name;
}
People.prototype.sayHello = function () {
    console.log('Hello');
}
var p = new People('xiaojianbang');

console.log(p.name); 	//xiaojianbang
p.sayHello(); 			//Hello
console.log(p['name']);	//xiaojianbang
p['sayHello'](); 		//Hello
