function _0x20ab1fxe2(a, b){
	return a + b;
}
function _0x20ab1fxe1(a, b){
	return _0x20ab1fxe2(a, b);
}
function _0x20ab1fxe3(a, b){
	return a + b;
}
function _0x20ab1fxe4(a, b){
	return _0x20ab1fxe3(a, b);
}
_0x20ab1fxe4('0', _0x20ab1fxe1(new Date().getMonth(), 1));
//输出 "07"