function stringToByte(str) {
    var byteArr = [];
    for (var i = 0; i < str.length; i++) {
        byteArr.push(str.charCodeAt(i));
    }
    return byteArr;
}
console.log(stringToByte('xiaojianbang'));
// [120, 105, 97, 111, 106, 105, 97, 110, 98, 97, 110, 103]
