var o = {
    x: function (a) {
        return a + 1000;
    }
};
function a(z) {
    z = 2000;
    return function (x, s, t) {
        return (t = (s = (x = o.x(100), o)).x(200), t + z);
    }();
}
console.log( a() );