function unicodeEnc(str) {
    var value = '';
    for (var i = 0; i < str.length; i++)
        value += "\\u" + ("0000" + parseInt(str.charCodeAt(i)).toString(16)).substr(-4);
    return value;
}
