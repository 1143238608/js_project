function _0x20ab1fxe1(a, b){
	return a + b;
}
//_0x20ab1fxe1(this.getMonth(), 1);
_0x20ab1fxe1(new Date().getMonth(), 1);	//输出7
//为了能够在控制台正常运行，把this改成new Date()