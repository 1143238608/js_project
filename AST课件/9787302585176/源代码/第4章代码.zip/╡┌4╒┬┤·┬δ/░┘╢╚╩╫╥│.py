import requests
from bs4 import BeautifulSoup

headers={
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
              'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'}

response=requests.get('http://www.baidu.com/s?ie=UTF-8&wd=Python')
response.encoding='utf8'
print(response.text)
soup=BeautifulSoup(response.text,'lxml')
titles=soup.select("div.result.c-container h3")
for title in titles:
    print(title.text)