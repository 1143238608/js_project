import requests
from bs4 import BeautifulSoup

#https://www.kuaidaili.com/free/inha/1/
#https://www.kuaidaili.com/free/inha/2/
#https://www.kuaidaili.com/free/inha/3/

def verify(proxy):
    try:
        response=requests.get('http://www.baidu.com/s?ie=UTF-8&wd=Python',proxies=proxy,timeout=3)
        if response.status_code==200:
            print("获取可用代理：{}".format(proxy))
    except:
        print('{}不可用'.format(proxy))

def get_proxy():
    for i in range(1,10):
        url='https://www.kuaidaili.com/free/inha/{}/'.format(i)
        response=requests.get(url)
        soup=BeautifulSoup(response.text,'lxml')
        datas=soup.select('tbody tr')
        proxies={'http': 'http://localhost:8888', 'https': 'http://localhost:8888'}
        for data in datas:
            ip=data.select('td')[0]
            port=data.select('td')[1]
            proxy = "http://" +ip.text+":"+port.text
            proxies['http']=proxy
            proxies['https']=proxy
            print("Get Proxy ","IP:",ip.text," Port:",port.text)
            verify(proxies)

get_proxy()