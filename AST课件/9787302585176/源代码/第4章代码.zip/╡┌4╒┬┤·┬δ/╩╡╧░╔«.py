import requests
from bs4 import BeautifulSoup

one=''.encode('utf-8')
two=''.encode('utf-8')
three=''.encode('utf-8')

myFont={one:1,two:2,three:3}
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,'
                  ' like Gecko) Chrome/79.0.3945.88 Safari/537.36'
}
response=requests.get('https://www.shixiseng.com/interns?page=1&keyword=Python',headers=headers)
soup=BeautifulSoup(response.text,'lxml')
salary=soup.select('span.day.font')
for s in salary:
    number=s.text.encode("utf-8").replace(one,b'1').replace(two,b'2').replace(three,b'3')
    print(number.decode("utf-8"))
