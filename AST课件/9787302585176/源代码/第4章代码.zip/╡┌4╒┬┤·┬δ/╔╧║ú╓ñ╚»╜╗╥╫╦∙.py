import requests

url='http://query.sse.com.cn//marketdata/tradedata/queryStockTopByPage.do?&jsonCallBack=jsonpCallback98728&isPagination=true&rankCondition=3&_=1594444522206'
headers={
    'Referer': 'http://www.sse.com.cn/market/overview/'
}
response=requests.get(url,headers=headers)
print(response.text)