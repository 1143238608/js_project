from PIL import Image
import pytesseract

image = Image.open('1234.png')
print(pytesseract.image_to_string(image))

import easyocr
reader = easyocr.Reader(['ch_sim','en']) # need to run only once to load model into memory
result = reader.readtext('9-7.jpg')